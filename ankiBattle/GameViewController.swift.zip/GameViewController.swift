//
//  GameViewController.swift
//  ankiBattle
//
//  Created by 生田拓登 on 2020/06/07.
//

import UIKit
import AVFoundation


class GameViewController: UIViewController {
    
    var totalNum = 0
    let maxNum = 364
    var selectNum = 0
    
    //    合計の数字
    @IBOutlet var num1Label: UILabel!
    //　　　足す数字
    @IBOutlet var num2Label: UILabel!
    //　　　選ぶ数字
    @IBOutlet var num3Label: UILabel!
    //    問題になる数字
    var probArray: [Int] = []
    //　　ランダムの宣言をtrue false
    var isFirst:Bool = true
    
    //  　問題になる数字を作る
    func makeNum() {
        var countNum = 1
        for _ in 0...51 {
            probArray.append(countNum)
            if probArray.count % 4 == 0{
                countNum += 1
            }
        }
        print("\(probArray)が生成されました。")
        
    }
//    効果音
    let keySoundPlayer = try! AVAudioPlayer(data: NSDataAsset(name: "cursor4")! .data)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeNum()
        let ran  = Int.random(in: 1 ... probArray.count)
        num2Label.text = String(probArray[ran - 1])
        probArray.remove(at: ran)
    }
    
    // 　選んだ数字があっているか判定
    func selectNumHantei() {
       
        let ran  = Int.random(in: 1 ... probArray.count)
        
        if totalNum != maxNum {
            print(probArray[ran - 1])
            if totalNum + probArray[ran - 1] == selectNum {
                num2Label.text = String(probArray[ran - 1])
                num1Label.text = String(totalNum + probArray[ran - 1])
                selectNum *= 0
                num3Label.text = String(selectNum)
                
            }
        }else{
            gameover()
        }
    }
    
    func gameover() {
            if num1Label.text == String(maxNum) {
                // 『終了』を表示して、"timeViewController"に遷移する
                
                performSegue(withIdentifier: "toViewResultTime", sender: nil)
                print("ゲーム終了")
                
            }
        }
        
        
        //   数字を押した時の効果音
        func koukaonn() {
            keySoundPlayer.currentTime = -1
            keySoundPlayer.play()
        }
        
        
        
        //  それぞれボタンの動作
        @IBAction func num1B() {
            if selectNum < 365 {
            selectNum = selectNum * 10 + 1
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
           }else{
                selectNum += 0
            }
    }
        @IBAction func num2B() {
           if selectNum < 365 {
            selectNum = selectNum * 10 + 2
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
           }else{
            selectNum += 0
            }
    }
        @IBAction func num3B() {
           if selectNum < 365 {
            selectNum = selectNum * 10 + 3
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
           }else{
            selectNum += 0
            }
            }
        @IBAction func num4B() {
            if selectNum < 365 {
            selectNum = selectNum * 10 + 4
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
            }else{
                selectNum += 0
            }
            }
        @IBAction func num5B() {
           if selectNum < 365 {
            selectNum = selectNum * 10 + 5
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
           }else{
            selectNum += 0
            }
            }
        @IBAction func num6B() {
            if selectNum < 365 {
            selectNum = selectNum * 10 + 6
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
            }else{
                selectNum += 0
            }
            }
        @IBAction func num7B() {
            if selectNum < 365 {
            selectNum = selectNum * 10 + 7
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
            }else{
                selectNum += 0
            }
    }
        @IBAction func num8B() {
            if selectNum < 365 {
            selectNum = selectNum * 10 + 8
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
            }else{
                selectNum += 0
            }
            }
        @IBAction func num9B() {
            if selectNum < 365 {
            selectNum = selectNum * 10 + 9
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
            }else{
                selectNum += 0
            }
    }
        @IBAction func num0B() {
           if selectNum < 365 {
            selectNum *= 10
            num3Label.text = String(selectNum)
            koukaonn() ; selectNumHantei() ; gameover()
           }else{
            selectNum += 0
            }
            }
        @IBAction func delete() {
            selectNum = selectNum / 10
            num3Label.text = String(selectNum)
            gameover()
            if selectNum != 0{
                koukaonn()
            }
            
        }
        
        
        
        
        
}
